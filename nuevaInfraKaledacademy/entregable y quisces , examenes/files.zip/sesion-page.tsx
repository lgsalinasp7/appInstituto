/**
 * app/academia/student/curso/sesion/[lessonId]/page.tsx
 *
 * Server Component — carga todos los datos de la sesión desde Prisma
 * y los pasa al LessonView (Client Component).
 */

import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { LessonView } from "@/modules/academia/components/student/LessonView";

interface Props {
  params: { lessonId: string };
}

export default async function SesionPage({ params }: Props) {
  const user = await getCurrentUser();
  if (!user) redirect("/auth/login");

  const lessonId = params.lessonId;

  // ── Cargar sesión con todos sus datos ────────────────────
  const lesson = await prisma.academyLesson.findUnique({
    where: { id: lessonId },
    include: {
      meta: true,
      module: {
        include: {
          course: { select: { id: true } },
          lessons: {
            where: { isActive: true },
            orderBy: { order: "asc" },
            select: { id: true, title: true, order: true, meta: { select: { weekNumber: true, dayOfWeek: true } } },
          },
        },
      },
      cralChallenges: { orderBy: { order: "asc" } },
      quizzes: {
        take: 1,
        include: {
          options: { orderBy: { id: "asc" } },
          results: { where: { userId: user.id }, take: 1 },
        },
      },
      deliverables: {
        take: 1,
        include: {
          checkItems: { orderBy: { order: "asc" } },
          submissions: {
            where: { userId: user.id },
            take: 1,
          },
        },
      },
      progress: { where: { userId: user.id }, take: 1 },
    },
  });

  if (!lesson) redirect("/academia/student");

  // Verificar que el usuario está matriculado en este curso
  const enrollment = await prisma.academyEnrollment.findFirst({
    where: { userId: user.id, courseId: lesson.module.courseId, status: "ACTIVE" },
  });
  if (!enrollment) redirect("/academia/student");

  // ── Completados de CRAL ──────────────────────────────────
  const cralCompletions = await prisma.academyCRALCompletion.findMany({
    where: {
      userId: user.id,
      challengeId: { in: lesson.cralChallenges.map(c => c.id) },
    },
    select: { challengeId: true },
  });
  const cralDoneIds = new Set(cralCompletions.map(c => c.challengeId));

  // ── Progreso de sesiones del módulo ─────────────────────
  const progressIds = await prisma.academyStudentProgress.findMany({
    where: {
      userId: user.id,
      lessonId: { in: lesson.module.lessons.map(l => l.id) },
      completed: true,
    },
    select: { lessonId: true },
  });
  const completedLessonIds = new Set(progressIds.map(p => p.lessonId));

  // ── Sesión anterior y siguiente ──────────────────────────
  const allLessons = lesson.module.lessons;
  const currentIndex = allLessons.findIndex(l => l.id === lessonId);
  const prevLesson = currentIndex > 0 ? allLessons[currentIndex - 1] : null;
  const nextLesson = currentIndex < allLessons.length - 1 ? allLessons[currentIndex + 1] : null;

  // ── Construir props ──────────────────────────────────────
  const quiz = lesson.quizzes[0] ?? null;
  const entregable = lesson.deliverables[0] ?? null;
  const submission = entregable?.submissions[0] ?? null;

  const conceptos = (lesson.meta?.concepts as Array<{
    key: string; titulo: string; historia?: string; cuerpo: string;
  }> ?? []);

  return (
    <LessonView
      lessonId={lessonId}
      titulo={lesson.title}
      descripcion={lesson.description ?? ""}
      historia={(lesson.meta as any)?.historia ?? undefined}
      kaledIntro={lesson.meta?.kaledIntro ?? undefined}
      analogia={lesson.meta?.analogyText ?? undefined}
      sessionType={(lesson.meta?.sessionType as string) ?? "TEORIA"}
      weekNumber={lesson.meta?.weekNumber ?? 1}
      dayOfWeek={(lesson.meta?.dayOfWeek as string) ?? "LUNES"}
      moduleOrder={lesson.module.order}
      moduleTitulo={lesson.module.title}
      conceptos={conceptos}
      retos={lesson.cralChallenges.map(c => ({
        id: c.id,
        phase: c.phase as "CONSTRUIR" | "ROMPER" | "AUDITAR" | "LANZAR",
        titulo: c.title,
        descripcion: c.description,
        isDone: cralDoneIds.has(c.id),
      }))}
      quiz={quiz ? {
        id: quiz.id,
        pregunta: quiz.question,
        opciones: quiz.options.map(o => ({
          id: o.id,
          label: o.label,
          texto: o.text,
          esCorrecta: o.isCorrect,
          feedback: o.feedback ?? undefined,
        })),
        resultado: quiz.results[0]
          ? { esCorrecta: quiz.results[0].isCorrect, opcionSeleccionadaId: quiz.results[0].selectedOptionId }
          : null,
      } : null}
      entregable={entregable ? {
        id: entregable.id,
        titulo: entregable.title,
        descripcion: entregable.description ?? "",
        esFinal: entregable.isFinal,
        items: entregable.checkItems.map(i => ({ id: i.id, texto: i.text })),
        submission: submission ? {
          status: submission.status,
          githubUrl: submission.githubUrl ?? undefined,
          deployUrl: submission.deployUrl ?? undefined,
          itemsMarcados: (submission.checkedItems as string[]) ?? [],
        } : null,
      } : null}
      estaCompleto={lesson.progress.some(p => p.completed)}
      sesionesDelModulo={allLessons.map(l => ({
        id: l.id,
        titulo: l.title,
        semana: l.meta?.weekNumber ?? 1,
        dia: (l.meta?.dayOfWeek as string) ?? "LUNES",
        estaCompleto: completedLessonIds.has(l.id),
        esActual: l.id === lessonId,
      }))}
      prevLessonId={prevLesson?.id}
      nextLessonId={nextLesson?.id}
    />
  );
}
