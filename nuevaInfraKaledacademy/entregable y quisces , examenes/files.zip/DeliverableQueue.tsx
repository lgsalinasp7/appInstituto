"use client";
/**
 * modules/academia/components/teacher/DeliverableQueue.tsx
 *
 * Panel del instructor: cola de entregables pendientes de revisión.
 * Tú ves: estudiante, sesión, checklist marcado, link de GitHub,
 * link de deploy, y botones para APROBAR o pedir CORRECCIÓN.
 *
 * Ruta: /academia/teacher/entregables
 * API: POST /api/academia/deliverables/[id]/review
 *
 * Stack: Next.js 16, Tailwind 4, Framer Motion, Lucide, Sonner
 */

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  Check, X, ExternalLink, ChevronDown, ChevronUp,
  Clock, CheckCircle, AlertCircle, Github,
} from "lucide-react";

// ── Tipos ──────────────────────────────────────────────────
interface CheckItem {
  id: string;
  texto: string;
  marcado: boolean;
}

interface EntregablePendiente {
  submissionId: string;
  deliverableId: string;
  deliverableTitulo: string;
  deliverableDescripcion: string;
  esFinal: boolean;
  weekNumber: number;
  sessionTitulo: string;
  moduleOrder: number;
  studentId: string;
  studentName: string;
  studentEmail: string;
  githubUrl?: string;
  deployUrl?: string;
  checkItems: CheckItem[];
  status: "ENTREGADO" | "EN_REVISION" | "APROBADO" | "RECHAZADO";
  submittedAt: string;
  // Evaluación pre-generada por Kaled (si existe)
  kaledEvaluacion?: {
    overallFeedback: string;
    strengths: string[];
    improvements: string[];
    socraticQuestions: string[];
    status: "PENDING_APPROVAL" | "APPROVED";
  } | null;
}

interface DeliverableQueueProps {
  filtroStatus?: "ENTREGADO" | "APROBADO" | "RECHAZADO" | "todos";
}

// ── Helpers ────────────────────────────────────────────────
function tiempoAtras(iso: string): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  const h = Math.floor(diff / 3600000);
  if (h < 1) return "Hace menos de 1 hora";
  if (h < 24) return `Hace ${h} hora${h > 1 ? "s" : ""}`;
  const dias = Math.floor(h / 24);
  return `Hace ${dias} día${dias > 1 ? "s" : ""}`;
}

const MODULE_COLOR: Record<number, string> = {
  1: "#3B82F6", 2: "#A855F7", 3: "#10B981", 4: "#F59E0B",
};

// ── Tarjeta individual de entregable ──────────────────────
function EntregableCard({
  item,
  onReview,
}: {
  item: EntregablePendiente;
  onReview: (submissionId: string, action: "APROBADO" | "NECESITA_CORRECCION", nota?: string) => Promise<void>;
}) {
  const [expandido, setExpandido] = useState(false);
  const [nota, setNota] = useState("");
  const [loading, setLoading] = useState<"aprobar" | "rechazar" | null>(null);
  const mc = MODULE_COLOR[item.moduleOrder] ?? "#3B82F6";
  const itemsMarcados = item.checkItems.filter(i => i.marcado).length;
  const totalItems = item.checkItems.length;
  const pct = totalItems > 0 ? Math.round((itemsMarcados / totalItems) * 100) : 0;

  const handleAprobar = async () => {
    setLoading("aprobar");
    await onReview(item.submissionId, "APROBADO", nota || undefined);
    setLoading(null);
  };

  const handleRechazar = async () => {
    if (!nota.trim()) {
      toast.error("Escribe una nota explicando qué debe corregir el estudiante.");
      return;
    }
    setLoading("rechazar");
    await onReview(item.submissionId, "NECESITA_CORRECCION", nota);
    setLoading(null);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="rounded-xl border overflow-hidden"
      style={{
        background: item.esFinal
          ? "linear-gradient(135deg, rgba(251,191,36,0.04), rgba(2,6,23,0.5))"
          : "rgba(255,255,255,0.02)",
        borderColor: item.status === "APROBADO"
          ? "rgba(16,185,129,0.3)"
          : item.status === "RECHAZADO"
          ? "rgba(239,68,68,0.3)"
          : item.esFinal
          ? "rgba(251,191,36,0.2)"
          : "rgba(255,255,255,0.06)",
      }}
    >
      {/* Header siempre visible */}
      <div className="p-4 flex items-start gap-3">
        {/* Avatar del estudiante */}
        <div className="w-9 h-9 rounded-full border border-white/[0.1] bg-white/[0.05] flex items-center justify-center text-[13px] font-bold text-slate-400 shrink-0">
          {item.studentName[0]?.toUpperCase()}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="text-[13px] font-bold text-white truncate">
              {item.studentName}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              {item.esFinal && (
                <span className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                  style={{ color: "#fbbf24", background: "rgba(251,191,36,0.15)" }}>
                  FINAL
                </span>
              )}
              <span className="text-[10px] text-slate-600">{tiempoAtras(item.submittedAt)}</span>
            </div>
          </div>

          <div className="text-[12px] text-slate-400 mb-2 leading-tight">
            <span style={{ color: mc }}>Módulo {item.moduleOrder}</span>
            <span className="text-slate-600 mx-1.5">·</span>
            <span>Sem.{item.weekNumber}</span>
            <span className="text-slate-600 mx-1.5">·</span>
            <span className="truncate">{item.deliverableTitulo}</span>
          </div>

          {/* Progreso del checklist */}
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1 bg-white/[0.05] rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all"
                style={{ width: `${pct}%`, background: pct === 100 ? "#10B981" : mc }} />
            </div>
            <span className="text-[10px] text-slate-600 shrink-0">
              {itemsMarcados}/{totalItems} ítems
            </span>
          </div>
        </div>

        {/* Botón expandir */}
        <button
          onClick={() => setExpandido(v => !v)}
          className="p-1.5 rounded-lg text-slate-600 hover:text-slate-400 hover:bg-white/[0.05] transition-colors shrink-0"
        >
          {expandido ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Contenido expandido */}
      <AnimatePresence>
        {expandido && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-white/[0.05] pt-4 space-y-4">

              {/* Links */}
              <div className="flex flex-wrap gap-2">
                {item.githubUrl && (
                  <a href={item.githubUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-[12px] text-slate-400 hover:text-white border border-white/[0.08] px-3 py-1.5 rounded-lg hover:bg-white/[0.05] transition-all">
                    <Github className="w-3.5 h-3.5" />
                    Ver repositorio
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {item.deployUrl && (
                  <a href={item.deployUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-[12px] text-slate-400 hover:text-white border border-white/[0.08] px-3 py-1.5 rounded-lg hover:bg-white/[0.05] transition-all">
                    <ExternalLink className="w-3.5 h-3.5" />
                    Ver publicado
                  </a>
                )}
              </div>

              {/* Checklist del estudiante */}
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.08em] text-slate-600 mb-2">
                  Checklist marcado por el estudiante
                </div>
                <div className="space-y-1.5">
                  {item.checkItems.map(ci => (
                    <div key={ci.id} className="flex items-start gap-2.5">
                      <div className="w-4 h-4 rounded border flex items-center justify-center shrink-0 mt-0.5"
                        style={{
                          borderColor: ci.marcado ? "#10B981" : "rgba(255,255,255,0.1)",
                          background: ci.marcado ? "#10B981" : "transparent",
                        }}>
                        {ci.marcado && <Check className="w-2.5 h-2.5 text-black" strokeWidth={2.5} />}
                      </div>
                      <span className={`text-[12px] leading-relaxed ${
                        ci.marcado ? "text-slate-400" : "text-slate-600"
                      }`}>
                        {ci.texto}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Evaluación de Kaled (si existe) */}
              {item.kaledEvaluacion && (
                <div className="rounded-xl p-4 border"
                  style={{ background: "rgba(8,145,178,0.05)", borderColor: "rgba(8,145,178,0.2)" }}>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-base">🤖</span>
                    <span className="text-[12px] font-bold text-cyan-400">Pre-evaluación de Kaled</span>
                    <span className="text-[10px] text-slate-600 ml-auto">Pendiente de tu aprobación</span>
                  </div>
                  <p className="text-[12px] text-slate-400 leading-relaxed mb-3">
                    {item.kaledEvaluacion.overallFeedback}
                  </p>
                  {item.kaledEvaluacion.strengths.length > 0 && (
                    <div className="mb-2">
                      <div className="text-[10px] text-emerald-400 font-bold mb-1">Fortalezas</div>
                      {item.kaledEvaluacion.strengths.map((s, i) => (
                        <div key={i} className="text-[11px] text-slate-500 flex gap-1.5">
                          <span>✓</span><span>{s}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {item.kaledEvaluacion.improvements.length > 0 && (
                    <div>
                      <div className="text-[10px] text-amber-400 font-bold mb-1">Áreas a mejorar</div>
                      {item.kaledEvaluacion.improvements.map((s, i) => (
                        <div key={i} className="text-[11px] text-slate-500 flex gap-1.5">
                          <span>→</span><span>{s}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Nota del instructor */}
              <div>
                <label className="text-[10px] font-bold uppercase tracking-[0.08em] text-slate-600 mb-1.5 block">
                  Nota para el estudiante (obligatoria si rechazas)
                </label>
                <textarea
                  value={nota}
                  onChange={(e) => setNota(e.target.value)}
                  placeholder="Escribe aquí el feedback para el estudiante..."
                  rows={3}
                  className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl px-3 py-2.5 text-[12px] text-white placeholder:text-slate-700 outline-none focus:border-cyan-500/40 transition-colors resize-none"
                />
              </div>

              {/* Acciones */}
              {item.status === "ENTREGADO" || item.status === "EN_REVISION" ? (
                <div className="flex gap-2">
                  <button
                    onClick={handleAprobar}
                    disabled={loading !== null}
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[13px] font-bold text-white transition-all disabled:opacity-50"
                    style={{ background: "linear-gradient(135deg, #059669, #10B981)" }}
                  >
                    <Check className="w-4 h-4" />
                    {loading === "aprobar" ? "Aprobando..." : "Aprobar ✓"}
                  </button>
                  <button
                    onClick={handleRechazar}
                    disabled={loading !== null}
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[13px] font-bold border transition-all disabled:opacity-50"
                    style={{ color: "#f87171", borderColor: "rgba(239,68,68,0.4)", background: "rgba(239,68,68,0.08)" }}
                  >
                    <X className="w-4 h-4" />
                    {loading === "rechazar" ? "Enviando..." : "Necesita corrección"}
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 py-2.5 px-4 rounded-xl"
                  style={{
                    background: item.status === "APROBADO" ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
                    border: `1px solid ${item.status === "APROBADO" ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"}`,
                  }}>
                  {item.status === "APROBADO"
                    ? <><Check className="w-4 h-4 text-emerald-400" /><span className="text-[13px] text-emerald-400 font-bold">Aprobado</span></>
                    : <><X className="w-4 h-4 text-red-400" /><span className="text-[13px] text-red-400 font-bold">Necesita corrección</span></>
                  }
                </div>
              )}

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Componente principal ───────────────────────────────────
export function DeliverableQueue({ filtroStatus = "ENTREGADO" }: DeliverableQueueProps) {
  const [items, setItems] = useState<EntregablePendiente[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtro, setFiltro] = useState(filtroStatus);

  // Cargar entregables
  const cargar = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/academia/teacher/deliverables?status=${filtro}`);
      if (res.ok) {
        const data = await res.json();
        setItems(data.items ?? []);
      }
    } catch {
      toast.error("Error al cargar los entregables.");
    } finally {
      setLoading(false);
    }
  }, [filtro]);

  useEffect(() => { cargar(); }, [cargar]);

  // Aprobar / pedir corrección
  const handleReview = useCallback(async (
    submissionId: string,
    action: "APROBADO" | "NECESITA_CORRECCION",
    nota?: string
  ) => {
    try {
      const res = await fetch(`/api/academia/deliverables/${submissionId}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: action, nota }),
      });
      if (res.ok) {
        toast.success(action === "APROBADO"
          ? "✓ Entregable aprobado — el estudiante fue notificado."
          : "→ Corrección solicitada — el estudiante fue notificado.");
        // Refrescar la lista
        await cargar();
      } else {
        const data = await res.json().catch(() => ({}));
        toast.error(data.error ?? "Error al procesar la revisión.");
      }
    } catch {
      toast.error("Error de conexión. Intenta de nuevo.");
    }
  }, [cargar]);

  // Contadores por estado
  const pendientes = items.filter(i => i.status === "ENTREGADO" || i.status === "EN_REVISION").length;
  const aprobados = items.filter(i => i.status === "APROBADO").length;
  const rechazados = items.filter(i => i.status === "RECHAZADO").length;

  return (
    <div>
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-black text-white tracking-tight mb-1">
            Cola de entregables
          </h2>
          <p className="text-[13px] text-slate-500">
            Revisa y aprueba los trabajos de tus estudiantes
          </p>
        </div>
        <button
          onClick={cargar}
          className="text-[11px] text-slate-500 hover:text-slate-300 border border-white/[0.08] px-3 py-1.5 rounded-lg hover:bg-white/[0.04] transition-all"
        >
          Actualizar
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: "Pendientes", value: pendientes, icon: Clock, color: "#fbbf24", status: "ENTREGADO" },
          { label: "Aprobados", value: aprobados, icon: CheckCircle, color: "#10B981", status: "APROBADO" },
          { label: "Corrección", value: rechazados, icon: AlertCircle, color: "#f87171", status: "RECHAZADO" },
        ].map(s => (
          <button key={s.status}
            onClick={() => setFiltro(s.status as any)}
            className="rounded-xl p-4 border text-left transition-all hover:border-opacity-60"
            style={filtro === s.status
              ? { background: `${s.color}10`, borderColor: `${s.color}40` }
              : { background: "rgba(255,255,255,0.02)", borderColor: "rgba(255,255,255,0.06)" }
            }
          >
            <div className="flex items-center gap-2 mb-1">
              <s.icon className="w-4 h-4" style={{ color: s.color }} />
              <span className="text-[10px] text-slate-500">{s.label}</span>
            </div>
            <div className="text-2xl font-black text-white">{s.value}</div>
          </button>
        ))}
      </div>

      {/* Lista */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 rounded-full border-2 border-cyan-500/30 border-t-cyan-400 animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-white/[0.06] p-12 flex flex-col items-center gap-3"
          style={{ background: "rgba(255,255,255,0.02)" }}>
          <CheckCircle className="w-10 h-10 text-emerald-400 opacity-40" />
          <div className="text-[13px] font-semibold text-white">
            {filtro === "ENTREGADO" ? "¡Sin entregables pendientes!" : "No hay entregables en esta categoría"}
          </div>
          <div className="text-[11px] text-slate-600">
            {filtro === "ENTREGADO" ? "Todos los entregables han sido revisados." : "Cambia el filtro para ver otros."}
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {items.map(item => (
              <EntregableCard
                key={item.submissionId}
                item={item}
                onReview={handleReview}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
