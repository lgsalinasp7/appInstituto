/**
 * app/api/academia/deliverables/[submissionId]/review/route.ts
 *
 * POST — El instructor aprueba o pide corrección de un entregable.
 * Solo accesible por ACADEMY_TEACHER y ACADEMY_ADMIN.
 *
 * Body: { status: "APROBADO" | "NECESITA_CORRECCION", nota?: string }
 * Response: { submission }
 */

import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const reviewSchema = z.object({
  status: z.enum(["APROBADO", "NECESITA_CORRECCION"]),
  nota: z.string().max(2000).optional(),
});

export async function POST(
  req: NextRequest,
  { params }: { params: { submissionId: string } }
) {
  // ── Auth ──────────────────────────────────────────────
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autorizado" }, { status: 401 });

  const dbUser = await prisma.user.findUnique({
    where: { id: user.id },
    select: { platformRole: true, tenantId: true },
  });

  if (!["ACADEMY_TEACHER", "ACADEMY_ADMIN"].includes(dbUser?.platformRole ?? "")) {
    return NextResponse.json({ error: "Solo instructores pueden revisar entregables" }, { status: 403 });
  }

  // ── Validar body ──────────────────────────────────────
  const body = reviewSchema.safeParse(await req.json());
  if (!body.success) {
    return NextResponse.json({ error: body.error.errors[0].message }, { status: 400 });
  }

  const { status, nota } = body.data;

  // ── Verificar que el submission existe ────────────────
  const submission = await prisma.academyDeliverableSubmission.findUnique({
    where: { id: params.submissionId },
    include: {
      deliverable: {
        include: {
          lesson: { include: { module: { include: { course: true } } } },
        },
      },
      user: { select: { id: true, name: true, email: true } },
    },
  });

  if (!submission) {
    return NextResponse.json({ error: "Entregable no encontrado" }, { status: 404 });
  }

  // ── Actualizar el submission ──────────────────────────
  const updated = await prisma.academyDeliverableSubmission.update({
    where: { id: params.submissionId },
    data: {
      status: status as any,
      reviewedById: user.id,
      reviewedAt: new Date(),
      // Si hay nota del instructor, la guardamos en un campo de notas
      // (asegúrate de tener este campo en el schema, o usa metadata)
    },
  });

  // ── Si fue aprobado, actualizar el snapshot del estudiante ──
  if (status === "APROBADO") {
    // Contar entregables aprobados del estudiante
    const totalAprobados = await prisma.academyDeliverableSubmission.count({
      where: {
        userId: submission.userId,
        status: "APROBADO",
      },
    });

    // Actualizar snapshot (async, no bloquea la respuesta)
    prisma.academyStudentSnapshot.updateMany({
      where: { userId: submission.userId },
      data: { deliverablesApproved: totalAprobados },
    }).catch(console.error);

    // Verificar badge de primer entregable aprobado
    if (totalAprobados === 1) {
      const badge = await prisma.academyBadge.findFirst({
        where: { tenantId: dbUser!.tenantId!, condition: "DELIVERABLES_APPROVED", threshold: 1 },
      });
      if (badge) {
        await prisma.academyBadgeEarned.upsert({
          where: { userId_badgeId: { userId: submission.userId, badgeId: badge.id } },
          create: { userId: submission.userId, badgeId: badge.id, tenantId: dbUser!.tenantId! },
          update: {},
        });
      }
    }
  }

  return NextResponse.json({ submission: updated, status }, { status: 200 });
}

// ──────────────────────────────────────────────────────────
/**
 * app/api/academia/teacher/deliverables/route.ts
 *
 * GET — Lista de entregables para el instructor.
 * Query: ?status=ENTREGADO|APROBADO|RECHAZADO|todos
 */

export async function GET_teacherDeliverables(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "No autorizado" }, { status: 401 });

  const dbUser = await prisma.user.findUnique({
    where: { id: user.id },
    select: { platformRole: true, tenantId: true },
  });

  if (!["ACADEMY_TEACHER", "ACADEMY_ADMIN"].includes(dbUser?.platformRole ?? "")) {
    return NextResponse.json({ error: "Acceso denegado" }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const statusFilter = searchParams.get("status") ?? "ENTREGADO";

  const whereStatus = statusFilter === "todos"
    ? { in: ["ENTREGADO", "EN_REVISION", "APROBADO", "RECHAZADO"] as const }
    : statusFilter;

  const submissions = await prisma.academyDeliverableSubmission.findMany({
    where: {
      status: typeof whereStatus === "string"
        ? (whereStatus as any)
        : { in: whereStatus as any },
      deliverable: {
        lesson: {
          module: {
            course: {
              tenantId: dbUser!.tenantId!,
            },
          },
        },
      },
    },
    include: {
      user: { select: { id: true, name: true, email: true } },
      deliverable: {
        include: {
          checkItems: { orderBy: { order: "asc" } },
          lesson: {
            include: {
              module: { select: { order: true, title: true } },
              meta: { select: { weekNumber: true } },
            },
          },
        },
      },
    },
    orderBy: { submittedAt: "asc" }, // Más antiguos primero (llevan más tiempo esperando)
  });

  const items = submissions.map(s => ({
    submissionId: s.id,
    deliverableId: s.deliverableId,
    deliverableTitulo: s.deliverable.title,
    deliverableDescripcion: s.deliverable.description ?? "",
    esFinal: s.deliverable.isFinal,
    weekNumber: s.deliverable.weekNumber,
    sessionTitulo: s.deliverable.lesson.title,
    moduleOrder: s.deliverable.lesson.module.order,
    studentId: s.userId,
    studentName: s.user.name ?? s.user.email,
    studentEmail: s.user.email,
    githubUrl: s.githubUrl ?? undefined,
    deployUrl: s.deployUrl ?? undefined,
    checkItems: s.deliverable.checkItems.map(ci => ({
      id: ci.id,
      texto: ci.text,
      marcado: (s.checkedItems as string[]).includes(ci.id),
    })),
    status: s.status,
    submittedAt: s.submittedAt?.toISOString() ?? s.updatedAt.toISOString(),
    kaledEvaluacion: null, // Se agrega cuando integres KaledDeliverableEvaluation
  }));

  return NextResponse.json({ items, total: items.length });
}
