"use client";
/**
 * modules/academia/components/student/LessonView.tsx
 *
 * Vista completa de una sesión para el estudiante:
 *   1. Header con metadata de la sesión
 *   2. Historia + intro de Kaled
 *   3. Analogía
 *   4. ESPACIO DE ANIMACIÓN REMOTION (placeholder listo para integrar)
 *   5. Conceptos interactivos (pills)
 *   6. Quiz de comprensión
 *   7. Retos CRAL (4 fases)
 *   8. Entregable semanal (checklist + URL de GitHub + enviar)
 *   9. Navegación anterior / siguiente / marcar completado
 *
 * Rutas de API usadas:
 *   POST /api/academia/quizzes/[quizId]/answer
 *   POST /api/academia/cral/[challengeId]/complete
 *   POST /api/academia/deliverables/[deliverableId]/submit
 *   POST /api/academia/lessons/[lessonId]/complete
 *
 * Stack: Next.js 16, Tailwind 4, Framer Motion, Lucide, Sonner
 * Auth: getCurrentUser() de @/lib/auth (NO Clerk)
 */

import { useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import {
  ChevronLeft, ChevronRight, Check, ExternalLink,
  BookOpen, MessageSquare, Lock,
} from "lucide-react";

// ── Tipos ──────────────────────────────────────────────────
export interface ConceptItem {
  key: string;
  titulo: string;
  historia?: string;
  cuerpo: string;
}

export interface CRALReto {
  id: string;
  phase: "CONSTRUIR" | "ROMPER" | "AUDITAR" | "LANZAR";
  titulo: string;
  descripcion: string;
  isDone: boolean;
}

export interface QuizOpcion {
  id: string;
  label: string;
  texto: string;
  esCorrecta: boolean;
  feedback?: string;
}

export interface QuizData {
  id: string;
  pregunta: string;
  opciones: QuizOpcion[];
  resultado: { esCorrecta: boolean; opcionSeleccionadaId?: string | null } | null;
}

export interface DeliverableCheckItem {
  id: string;
  texto: string;
}

export interface EntregableData {
  id: string;
  titulo: string;
  descripcion: string;
  esFinal: boolean;
  items: DeliverableCheckItem[];
  submission: {
    status: string;
    githubUrl?: string;
    deployUrl?: string;
    itemsMarcados: string[];
  } | null;
}

export interface SesionNavItem {
  id: string;
  titulo: string;
  semana: number;
  dia: string;
  estaCompleto: boolean;
  esActual: boolean;
}

export interface LessonViewProps {
  lessonId: string;
  titulo: string;
  descripcion: string;
  historia?: string;
  kaledIntro?: string;
  analogia?: string;
  sessionType: string;
  weekNumber: number;
  dayOfWeek: string;
  moduleOrder: number;
  moduleTitulo: string;
  conceptos: ConceptItem[];
  retos: CRALReto[];
  quiz: QuizData | null;
  entregable: EntregableData | null;
  estaCompleto: boolean;
  sesionesDelModulo: SesionNavItem[];
  prevLessonId?: string;
  nextLessonId?: string;
  // Remotion: cuando tengas la animación lista, pasa el componente aquí
  AnimacionRemotionComponent?: React.FC;
  animacionDuracionFrames?: number;
}

// ── Tokens visuales ────────────────────────────────────────
const MODULE_COLOR: Record<number, string> = {
  1: "#3B82F6", 2: "#A855F7", 3: "#10B981", 4: "#F59E0B",
};

const CRAL_CONFIG = {
  CONSTRUIR: { label: "Construir", pct: "70%", color: "#10B981", emoji: "🔨",
    desc: "Intenta siempre primero. El arquitecto construye antes de preguntar." },
  ROMPER:    { label: "Romper",    pct: "10%", color: "#EF4444", emoji: "💥",
    desc: "Rompe intencionalmente para entender por qué funciona." },
  AUDITAR:   { label: "Auditar",   pct: "10%", color: "#F59E0B", emoji: "🔍",
    desc: "Revisa con criterio técnico. No todo lo que genera la IA es correcto." },
  LANZAR:    { label: "Lanzar",    pct: "10%", color: "#3B82F6", emoji: "🚀",
    desc: "Si no está en internet, no existe. Siempre despliega." },
};

const SESSION_BADGE: Record<string, string> = {
  TEORIA: "Teoría", PRACTICA: "Práctica", ENTREGABLE: "Entregable", LIVE: "Live",
};

const DAY_ES: Record<string, string> = {
  LUNES: "Lun", MIERCOLES: "Mié", VIERNES: "Vie",
};

const fadeUp = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } };

// ── Componente principal ───────────────────────────────────
export function LessonView({
  lessonId, titulo, descripcion, historia, kaledIntro, analogia,
  sessionType, weekNumber, dayOfWeek, moduleOrder, moduleTitulo,
  conceptos, retos, quiz, entregable, estaCompleto,
  sesionesDelModulo, prevLessonId, nextLessonId,
  AnimacionRemotionComponent, animacionDuracionFrames = 300,
}: LessonViewProps) {
  const router = useRouter();
  const mc = MODULE_COLOR[moduleOrder] ?? "#3B82F6";
  const badge = SESSION_BADGE[sessionType] ?? "Sesión";

  // ── Estado local ─────────────────────────────────────────
  const [conceptoActivo, setConceptoActivo] = useState<string | null>(null);
  const [quizState, setQuizState] = useState<{
    seleccionada: string | null; respondida: boolean; esCorrecta: boolean; feedback?: string;
  }>({
    seleccionada: quiz?.resultado?.opcionSeleccionadaId ?? null,
    respondida: quiz?.resultado != null,
    esCorrecta: quiz?.resultado?.esCorrecta ?? false,
    feedback: undefined,
  });
  const [retosState, setRetosState] = useState<Record<string, boolean>>(
    Object.fromEntries(retos.map((r) => [r.id, r.isDone]))
  );
  const [itemsMarcados, setItemsMarcados] = useState<Set<string>>(
    new Set(entregable?.submission?.itemsMarcados ?? [])
  );
  const [githubUrl, setGithubUrl] = useState(entregable?.submission?.githubUrl ?? "");
  const [deployUrl, setDeployUrl] = useState(entregable?.submission?.deployUrl ?? "");
  const [enviandoEntregable, setEnviandoEntregable] = useState(false);
  const [completado, setCompletado] = useState(estaCompleto);
  const [sidebarVisible, setSidebarVisible] = useState(true);

  // ── Handlers ──────────────────────────────────────────────
  const responderQuiz = useCallback(async (opcion: QuizOpcion) => {
    if (quizState.respondida || !quiz) return;

    // Optimistic UI
    setQuizState({
      seleccionada: opcion.id,
      respondida: true,
      esCorrecta: opcion.esCorrecta,
      feedback: opcion.feedback,
    });

    try {
      await fetch(`/api/academia/quizzes/${quiz.id}/answer`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ selectedOptionId: opcion.id }),
      });
      if (opcion.esCorrecta) toast.success("¡Correcto! 🎯");
      else toast.error("Incorrecto — revisa el concepto e intenta entenderlo.");
    } catch {
      toast.error("Error al guardar respuesta. Verifica tu conexión.");
    }
  }, [quizState.respondida, quiz]);

  const completarReto = useCallback(async (retoId: string) => {
    setRetosState((prev) => ({ ...prev, [retoId]: true }));
    try {
      const res = await fetch(`/api/academia/cral/${retoId}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (res.ok) toast.success("¡Fase completada! 🚀");
      else setRetosState((prev) => ({ ...prev, [retoId]: false }));
    } catch {
      setRetosState((prev) => ({ ...prev, [retoId]: false }));
      toast.error("Error al guardar. Verifica tu conexión.");
    }
  }, []);

  const toggleItem = useCallback((itemId: string) => {
    setItemsMarcados((prev) => {
      const next = new Set(prev);
      if (next.has(itemId)) next.delete(itemId);
      else next.add(itemId);
      return next;
    });
  }, []);

  const enviarEntregable = useCallback(async () => {
    if (!entregable || itemsMarcados.size === 0) return;
    setEnviandoEntregable(true);
    try {
      const res = await fetch(`/api/academia/deliverables/${entregable.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          githubUrl: githubUrl.trim() || undefined,
          deployUrl: deployUrl.trim() || undefined,
          checkedItems: [...itemsMarcados],
        }),
      });
      if (res.ok) {
        toast.success("¡Entregable enviado! 📦 El instructor lo revisará pronto.");
        router.refresh();
      } else {
        const data = await res.json().catch(() => ({}));
        toast.error(data.error ?? "Error al enviar. Intenta de nuevo.");
      }
    } catch {
      toast.error("Error de conexión. Verifica tu internet e intenta de nuevo.");
    } finally {
      setEnviandoEntregable(false);
    }
  }, [entregable, itemsMarcados, githubUrl, deployUrl, router]);

  const marcarCompletado = useCallback(async () => {
    if (completado) return;
    setCompletado(true);
    try {
      const res = await fetch(`/api/academia/lessons/${lessonId}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoProgress: 100 }),
      });
      if (res.ok) {
        toast.success("✓ Sesión marcada como completada");
        router.refresh();
      } else {
        setCompletado(false);
        toast.error("Error al guardar. Intenta de nuevo.");
      }
    } catch {
      setCompletado(false);
      toast.error("Error de conexión.");
    }
  }, [completado, lessonId, router]);

  // ── Render ────────────────────────────────────────────────
  return (
    <div className="flex h-full min-h-0">

      {/* ── SIDEBAR DE SESIONES DEL MÓDULO ── */}
      <AnimatePresence>
        {sidebarVisible && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 220, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="hidden xl:flex flex-col shrink-0 border-r border-white/[0.06] h-full overflow-hidden"
            style={{ background: "rgba(2,6,23,0.7)" }}
          >
            {/* Módulo header */}
            <div className="p-4 border-b border-white/[0.05]">
              <div className="text-[10px] font-bold uppercase tracking-[0.12em] mb-1"
                style={{ color: mc }}>
                Módulo {moduleOrder}
              </div>
              <div className="text-[12px] font-bold text-white leading-tight">
                {moduleTitulo}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex-1 h-1 bg-white/[0.05] rounded-full overflow-hidden">
                  <div className="h-full rounded-full"
                    style={{
                      width: `${(sesionesDelModulo.filter(s => s.estaCompleto).length / sesionesDelModulo.length) * 100}%`,
                      background: mc,
                    }} />
                </div>
                <span className="text-[9px] text-slate-600">
                  {sesionesDelModulo.filter(s => s.estaCompleto).length}/{sesionesDelModulo.length}
                </span>
              </div>
            </div>

            {/* Lista de sesiones */}
            <div className="flex-1 overflow-y-auto p-2 scrollbar-hide">
              {Array.from(new Set(sesionesDelModulo.map(s => s.semana))).map(semana => (
                <div key={semana}>
                  <div className="text-[9px] font-bold uppercase tracking-[0.1em] text-slate-700 px-2 py-2">
                    Semana {semana}
                  </div>
                  {sesionesDelModulo.filter(s => s.semana === semana).map(s => (
                    <Link key={s.id} href={`/academia/student/curso/sesion/${s.id}`}
                      className="flex items-center gap-2 px-2 py-2 rounded-lg mb-0.5 transition-all text-[11px] border"
                      style={s.esActual
                        ? { borderColor: `${mc}40`, background: `${mc}10`, color: "#fff" }
                        : { borderColor: "transparent", color: "#64748b" }
                      }
                    >
                      {/* Indicador de completado */}
                      <div className="w-4 h-4 rounded-full border flex items-center justify-center shrink-0"
                        style={{
                          borderColor: s.estaCompleto ? "#10B981"
                            : s.esActual ? mc : "rgba(255,255,255,0.1)",
                          background: s.estaCompleto ? "#10B981"
                            : s.esActual ? `${mc}20` : "transparent",
                        }}>
                        {s.estaCompleto && (
                          <svg className="w-2 h-2" fill="none" viewBox="0 0 8 8">
                            <path d="M1 4l2 2 4-4" stroke="#000" strokeWidth="1.5" strokeLinecap="round" />
                          </svg>
                        )}
                        {!s.estaCompleto && s.esActual && (
                          <div className="w-1.5 h-1.5 rounded-full" style={{ background: mc }} />
                        )}
                      </div>
                      <span className="flex-1 truncate leading-tight">{s.titulo}</span>
                      <span className="text-[9px] text-slate-700 shrink-0">
                        {DAY_ES[s.dia]}
                      </span>
                    </Link>
                  ))}
                </div>
              ))}
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* ── CONTENIDO PRINCIPAL ── */}
      <div className="flex-1 overflow-y-auto min-w-0">
        <div className="max-w-2xl mx-auto px-4 lg:px-8 py-6 pb-24">

          {/* Breadcrumb + botón sidebar */}
          <div className="flex items-center justify-between mb-5">
            <nav className="flex items-center gap-2 text-[11px] text-slate-600">
              <Link href="/academia/student/curso"
                className="hover:text-slate-400 transition-colors">
                Bootcamp
              </Link>
              <span>›</span>
              <span>Módulo {moduleOrder}</span>
              <span>›</span>
              <span className="text-slate-400">
                Sem.{weekNumber} · {DAY_ES[dayOfWeek]}
              </span>
            </nav>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold px-2.5 py-1 rounded-full border"
                style={{ color: mc, borderColor: `${mc}40`, background: `${mc}15` }}>
                {badge}
              </span>
              <button
                onClick={() => setSidebarVisible(v => !v)}
                className="hidden xl:flex items-center justify-center w-7 h-7 rounded-lg text-slate-600 hover:text-slate-400 hover:bg-white/[0.05] transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Título */}
          <h1 className="text-2xl lg:text-3xl font-black text-white tracking-tight font-display mb-2 leading-tight">
            {titulo}
          </h1>
          <p className="text-slate-500 text-sm leading-relaxed mb-8">{descripcion}</p>

          {/* ── 1. HISTORIA ── */}
          {historia && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-7 rounded-xl p-5 border border-white/[0.06]"
              style={{ background: "rgba(255,255,255,0.02)" }}
            >
              <div className="text-[10px] font-bold uppercase tracking-[0.1em] text-slate-600 mb-3">
                Historia
              </div>
              <p className="text-[14px] text-slate-400 leading-[1.8] whitespace-pre-line">
                {historia}
              </p>
            </motion.div>
          )}

          {/* ── 2. INTRO KALED ── */}
          {kaledIntro && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-7 rounded-xl p-5 border flex gap-3"
              style={{
                background: "linear-gradient(135deg, rgba(8,145,178,0.06), rgba(2,6,23,0.4))",
                borderColor: "rgba(8,145,178,0.2)",
              }}
            >
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0 border"
                style={{ background: "rgba(8,145,178,0.15)", borderColor: "rgba(8,145,178,0.3)" }}>
                🤖
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[13px] font-bold text-white">Kaled</span>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full"
                    style={{ background: "rgba(8,145,178,0.15)", color: "#38bdf8" }}>
                    TUTOR
                  </span>
                </div>
                <p className="text-[13px] text-slate-400 leading-relaxed italic whitespace-pre-line">
                  {kaledIntro}
                </p>
                <Link href="/academia/student/tutor"
                  className="inline-flex items-center gap-1.5 mt-3 text-[11px] font-semibold text-cyan-400 hover:underline">
                  <MessageSquare className="w-3.5 h-3.5" />
                  Preguntarle algo a Kaled
                  <ExternalLink className="w-3 h-3" />
                </Link>
              </div>
            </motion.div>
          )}

          {/* ── 3. ANALOGÍA ── */}
          {analogia && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-7 rounded-xl p-4 border-l-[3px]"
              style={{
                background: "rgba(251,191,36,0.04)",
                borderLeftColor: "#fbbf24",
                border: "1px solid rgba(251,191,36,0.12)",
                borderLeft: "3px solid #fbbf24",
              }}
            >
              <div className="text-[10px] font-bold uppercase tracking-[0.1em] text-amber-400 mb-2">
                Analogía de Kaled
              </div>
              <p className="text-[13px] text-slate-400 leading-relaxed whitespace-pre-line">
                {analogia}
              </p>
            </motion.div>
          )}

          {/* ── 4. ESPACIO DE ANIMACIÓN REMOTION ── */}
          <motion.div
            initial="hidden" animate="show" variants={fadeUp}
            className="mb-8"
          >
            <div className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-600 mb-3">
              Animación explicativa
            </div>

            {AnimacionRemotionComponent ? (
              // ── CUANDO TENGAS REMOTION LISTO: descomenta esto ──
              // import { Player } from "@remotion/player";
              // <Player
              //   component={AnimacionRemotionComponent}
              //   durationInFrames={animacionDuracionFrames}
              //   fps={30}
              //   compositionWidth={1280}
              //   compositionHeight={720}
              //   style={{ width: "100%", borderRadius: "12px" }}
              //   controls
              //   loop={false}
              // />
              <div className="w-full aspect-video rounded-xl border border-white/[0.06] flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.02)" }}>
                <span className="text-slate-600 text-sm">Cargando animación...</span>
              </div>
            ) : (
              /* PLACEHOLDER hasta que tengas la animación de Remotion */
              <div className="w-full aspect-video rounded-xl border border-dashed border-white/[0.12] flex flex-col items-center justify-center gap-3"
                style={{ background: "rgba(255,255,255,0.015)" }}>
                <div className="w-12 h-12 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center">
                  <div className="w-0 h-0 border-t-[7px] border-b-[7px] border-l-[12px] border-transparent border-l-slate-600 ml-1" />
                </div>
                <div className="text-center">
                  <div className="text-[13px] font-medium text-slate-500 mb-1">
                    Animación: {titulo}
                  </div>
                  <div className="text-[11px] text-slate-700">
                    Aquí irá la animación de Remotion · ~30 segundos
                  </div>
                </div>
              </div>
            )}
          </motion.div>

          {/* ── 5. CONCEPTOS ── */}
          {conceptos.length > 0 && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-8"
            >
              <div className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-600 mb-3">
                Conceptos de la sesión
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                {conceptos.map((c) => (
                  <button key={c.key}
                    onClick={() => setConceptoActivo(conceptoActivo === c.key ? null : c.key)}
                    className="px-3 py-1.5 rounded-full border text-[12px] font-medium transition-all"
                    style={conceptoActivo === c.key
                      ? { background: `${mc}15`, borderColor: `${mc}40`, color: "#fff" }
                      : { background: "rgba(255,255,255,0.03)", borderColor: "rgba(255,255,255,0.1)", color: "#94a3b8" }
                    }
                  >
                    {c.titulo.split("—")[0].split("(")[0].trim()}
                  </button>
                ))}
              </div>

              <AnimatePresence>
                {conceptoActivo && (() => {
                  const c = conceptos.find(c => c.key === conceptoActivo);
                  return c ? (
                    <motion.div key={conceptoActivo}
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      className="rounded-xl p-5 border border-white/[0.08]"
                      style={{ background: "rgba(255,255,255,0.03)" }}
                    >
                      <div className="text-[14px] font-bold text-white mb-2">{c.titulo}</div>
                      {c.historia && (
                        <p className="text-[12px] text-slate-600 border-l-2 border-white/[0.1] pl-3 mb-3 italic leading-relaxed"
                          style={{ borderRadius: 0 }}>
                          {c.historia}
                        </p>
                      )}
                      <p className="text-[13px] text-slate-400 leading-[1.8] whitespace-pre-line">
                        {c.cuerpo}
                      </p>
                    </motion.div>
                  ) : null;
                })()}
              </AnimatePresence>
            </motion.div>
          )}

          {/* ── 6. QUIZ ── */}
          {quiz && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-8 rounded-xl p-5 border border-white/[0.08]"
              style={{ background: "rgba(255,255,255,0.02)" }}
            >
              <div className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-600 mb-4">
                Verifica tu comprensión
              </div>
              <p className="text-[14px] font-medium text-white leading-relaxed mb-5">
                {quiz.pregunta}
              </p>

              <div className="flex flex-col gap-2.5">
                {quiz.opciones.map((op) => {
                  const esSeleccionada = quizState.seleccionada === op.id
                    || quiz.resultado?.opcionSeleccionadaId === op.id;

                  let estilo: React.CSSProperties = {
                    background: "rgba(255,255,255,0.02)",
                    borderColor: "rgba(255,255,255,0.08)",
                    color: "#94a3b8",
                    cursor: "pointer",
                  };
                  if (quizState.respondida) {
                    if (esSeleccionada && op.esCorrecta)
                      estilo = { background: "rgba(16,185,129,0.1)", borderColor: "rgba(16,185,129,0.4)", color: "#34d399" };
                    else if (esSeleccionada && !op.esCorrecta)
                      estilo = { background: "rgba(239,68,68,0.1)", borderColor: "rgba(239,68,68,0.4)", color: "#f87171" };
                    else
                      estilo = { background: "transparent", borderColor: "rgba(255,255,255,0.04)", color: "#475569", cursor: "not-allowed" };
                  }

                  return (
                    <button key={op.id}
                      disabled={quizState.respondida}
                      onClick={() => responderQuiz(op)}
                      className="w-full text-left px-4 py-3 rounded-xl border text-[13px] transition-all flex items-center gap-3"
                      style={estilo}
                    >
                      <span className="w-6 h-6 rounded-full border flex items-center justify-center text-[10px] font-bold shrink-0"
                        style={{
                          borderColor: quizState.respondida && esSeleccionada
                            ? op.esCorrecta ? "#10B981" : "#EF4444"
                            : "rgba(255,255,255,0.15)",
                        }}>
                        {op.label}
                      </span>
                      <span className="flex-1">{op.texto}</span>
                      {quizState.respondida && esSeleccionada && (
                        <span className="text-base">{op.esCorrecta ? "✅" : "❌"}</span>
                      )}
                    </button>
                  );
                })}
              </div>

              <AnimatePresence>
                {quizState.respondida && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 p-4 rounded-xl text-[13px] leading-relaxed"
                    style={{
                      background: quizState.esCorrecta ? "rgba(16,185,129,0.08)" : "rgba(239,68,68,0.08)",
                      border: `1px solid ${quizState.esCorrecta ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"}`,
                      color: quizState.esCorrecta ? "#34d399" : "#f87171",
                    }}
                  >
                    {quizState.feedback
                      ?? (quizState.esCorrecta
                        ? "¡Correcto! Ese es el pensamiento de un arquitecto. 🎯"
                        : "Incorrecto. Revisa el concepto correspondiente y vuelve a intentarlo.")}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {/* ── 7. CRAL ── */}
          {retos.length > 0 && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-8"
            >
              <div className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-600 mb-4">
                Metodología CRAL
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {retos.map((reto) => {
                  const cfg = CRAL_CONFIG[reto.phase];
                  const hecho = retosState[reto.id] ?? reto.isDone;

                  return (
                    <div key={reto.id}
                      className="rounded-xl p-4 border transition-all"
                      style={{
                        background: `${cfg.color}08`,
                        borderColor: hecho ? cfg.color : `${cfg.color}30`,
                      }}
                    >
                      {/* Phase header */}
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{cfg.emoji}</span>
                          <span className="text-[10px] font-bold uppercase tracking-[0.1em]"
                            style={{ color: cfg.color }}>
                            {cfg.label} · {cfg.pct}
                          </span>
                        </div>
                        {hecho && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                            style={{ color: cfg.color, background: `${cfg.color}20` }}>
                            ✓ Listo
                          </span>
                        )}
                      </div>

                      <div className="text-[13px] font-bold text-white mb-1.5">
                        {reto.titulo}
                      </div>
                      <p className="text-[12px] text-slate-500 leading-relaxed mb-3">
                        {reto.descripcion}
                      </p>

                      <div className="flex gap-2">
                        {hecho ? (
                          <div className="flex-1 py-1.5 rounded-lg text-[11px] font-bold text-center"
                            style={{ color: cfg.color, background: `${cfg.color}15` }}>
                            Completado
                          </div>
                        ) : (
                          <button
                            onClick={() => completarReto(reto.id)}
                            className="flex-1 py-1.5 rounded-lg text-[11px] font-bold border transition-all hover:opacity-80"
                            style={{ color: cfg.color, borderColor: `${cfg.color}40`, background: `${cfg.color}10` }}
                          >
                            Marcar como completado
                          </button>
                        )}
                        <Link href="/academia/student/tutor"
                          className="px-3 py-1.5 rounded-lg text-[11px] text-slate-500 border border-white/[0.08] hover:bg-white/[0.05] transition-colors">
                          Kaled
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* ── 8. ENTREGABLE ── */}
          {entregable && (
            <motion.div
              initial="hidden" animate="show" variants={fadeUp}
              className="mb-8 rounded-xl p-5 border"
              style={{
                background: entregable.esFinal
                  ? "linear-gradient(135deg, rgba(251,191,36,0.06), rgba(2,6,23,0.4))"
                  : "linear-gradient(135deg, rgba(59,130,246,0.06), rgba(2,6,23,0.4))",
                borderColor: entregable.esFinal
                  ? "rgba(251,191,36,0.25)"
                  : "rgba(59,130,246,0.25)",
              }}
            >
              <div className="text-[10px] font-bold uppercase tracking-[0.12em] mb-2"
                style={{ color: entregable.esFinal ? "#fbbf24" : "#38bdf8" }}>
                {entregable.esFinal ? "🏆 Entregable integrador del módulo" : "📦 Entregable semanal"}
              </div>
              <h3 className="text-[15px] font-bold text-white mb-2">
                {entregable.titulo}
              </h3>
              <p className="text-[13px] text-slate-500 leading-relaxed mb-5">
                {entregable.descripcion}
              </p>

              {/* Checklist */}
              <div className="space-y-3 mb-5">
                {entregable.items.map((item) => {
                  const marcado = itemsMarcados.has(item.id);
                  const yaAprobado = entregable.submission?.status === "APROBADO";

                  return (
                    <div key={item.id}
                      onClick={() => !yaAprobado && toggleItem(item.id)}
                      className={`flex items-start gap-3 group ${!yaAprobado ? "cursor-pointer" : "cursor-default"}`}
                    >
                      <div className="w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 transition-all"
                        style={{
                          borderColor: marcado ? "#10B981" : "rgba(255,255,255,0.12)",
                          background: marcado ? "#10B981" : "transparent",
                        }}>
                        {marcado && <Check className="w-3 h-3 text-black" strokeWidth={2.5} />}
                      </div>
                      <span className={`text-[13px] leading-relaxed transition-colors ${
                        marcado ? "text-slate-500 line-through" : "text-slate-300 group-hover:text-white"
                      }`}>
                        {item.texto}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Progreso del checklist */}
              <div className="flex items-center gap-3 mb-5">
                <div className="flex-1 h-1 bg-white/[0.05] rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all"
                    style={{
                      width: `${(itemsMarcados.size / entregable.items.length) * 100}%`,
                      background: entregable.esFinal ? "#fbbf24" : "#38bdf8",
                    }} />
                </div>
                <span className="text-[11px] text-slate-600">
                  {itemsMarcados.size}/{entregable.items.length}
                </span>
              </div>

              {/* URLs */}
              {entregable.submission?.status !== "APROBADO" && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                  <div>
                    <label className="text-[10px] text-slate-600 mb-1.5 block">
                      Enlace de GitHub
                    </label>
                    <input
                      value={githubUrl}
                      onChange={(e) => setGithubUrl(e.target.value)}
                      placeholder="https://github.com/tu-usuario/proyecto"
                      className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl px-3 py-2 text-[12px] text-white placeholder:text-slate-700 outline-none focus:border-cyan-500/40 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-600 mb-1.5 block">
                      Enlace publicado (opcional)
                    </label>
                    <input
                      value={deployUrl}
                      onChange={(e) => setDeployUrl(e.target.value)}
                      placeholder="https://mi-proyecto.netlify.app"
                      className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl px-3 py-2 text-[12px] text-white placeholder:text-slate-700 outline-none focus:border-cyan-500/40 transition-colors"
                    />
                  </div>
                </div>
              )}

              {/* Estado y botón */}
              {entregable.submission?.status === "APROBADO" ? (
                <div className="flex items-center gap-2 py-3 px-4 rounded-xl"
                  style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)" }}>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-[13px] font-bold text-emerald-400">
                    Aprobado por el instructor ✓
                  </span>
                </div>
              ) : entregable.submission?.status === "ENTREGADO" ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 py-2.5 px-4 rounded-xl"
                    style={{ background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.3)" }}>
                    <span className="text-[13px] text-blue-400">
                      📬 Enviado — esperando revisión del instructor
                    </span>
                  </div>
                  <button
                    onClick={enviarEntregable}
                    disabled={enviandoEntregable || itemsMarcados.size === 0}
                    className="w-full py-2.5 rounded-xl text-[12px] font-medium text-slate-400 border border-white/[0.06] hover:bg-white/[0.04] transition-all disabled:opacity-30"
                  >
                    Actualizar entrega
                  </button>
                </div>
              ) : (
                <button
                  onClick={enviarEntregable}
                  disabled={enviandoEntregable || itemsMarcados.size === 0}
                  className="w-full py-3 rounded-xl text-[13px] font-bold text-white transition-all disabled:opacity-40 hover:opacity-90"
                  style={{
                    background: entregable.esFinal
                      ? "linear-gradient(135deg, #d97706, #fbbf24)"
                      : "linear-gradient(135deg, #1d4ed8, #3b82f6)",
                  }}
                >
                  {enviandoEntregable
                    ? "Enviando..."
                    : itemsMarcados.size === 0
                    ? "Marca al menos un ítem del checklist para enviar"
                    : `Enviar entregable →`}
                </button>
              )}
            </motion.div>
          )}

          {/* ── 9. NAVEGACIÓN ── */}
          <div className="flex items-center justify-between pt-6 border-t border-white/[0.06]">
            {prevLessonId ? (
              <Link href={`/academia/student/curso/sesion/${prevLessonId}`}
                className="flex items-center gap-2 text-[12px] text-slate-500 hover:text-slate-300 transition-colors px-4 py-2 rounded-xl border border-white/[0.08] hover:bg-white/[0.04]">
                <ChevronLeft className="w-4 h-4" />
                Sesión anterior
              </Link>
            ) : <div />}

            <button
              onClick={marcarCompletado}
              disabled={completado}
              className="px-6 py-2.5 rounded-xl text-[13px] font-bold text-white transition-all hover:opacity-90 disabled:cursor-not-allowed"
              style={completado
                ? { background: "rgba(16,185,129,0.15)", color: "#34d399", border: "1px solid rgba(16,185,129,0.3)" }
                : { background: `linear-gradient(135deg, ${mc}cc, ${mc}88)` }
              }
            >
              {completado ? "✓ Sesión completada" : "Marcar como vista →"}
            </button>

            {nextLessonId ? (
              <Link href={`/academia/student/curso/sesion/${nextLessonId}`}
                className="flex items-center gap-2 text-[12px] text-slate-500 hover:text-slate-300 transition-colors px-4 py-2 rounded-xl border border-white/[0.08] hover:bg-white/[0.04]">
                Siguiente sesión
                <ChevronRight className="w-4 h-4" />
              </Link>
            ) : (
              <Link href="/academia/student"
                className="flex items-center gap-2 text-[12px] text-slate-500 hover:text-slate-300 transition-colors px-4 py-2 rounded-xl border border-white/[0.08] hover:bg-white/[0.04]">
                Volver al dashboard
                <ChevronRight className="w-4 h-4" />
              </Link>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
